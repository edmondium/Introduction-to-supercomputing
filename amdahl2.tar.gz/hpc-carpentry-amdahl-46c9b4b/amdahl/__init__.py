from . import amdahl
