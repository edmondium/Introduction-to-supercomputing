from . import amdahl


def main():
    amdahl()


if __name__ == "__main__":
    main()
